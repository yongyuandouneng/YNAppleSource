

int var = 5;
void func() { }

