#include <string.h>

void bar()
{
	strcpy(NULL, NULL);
}
