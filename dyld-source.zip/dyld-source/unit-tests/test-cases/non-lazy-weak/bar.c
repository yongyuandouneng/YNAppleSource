

__attribute__((weak)) int bar = 10;
