

int bar = 10;
